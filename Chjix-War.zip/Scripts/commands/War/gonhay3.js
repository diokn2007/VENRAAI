

const config = {
  "name": "n5",
  "aliases": ["🤣"],
  "description": "",
  "usage": "",
  "cooldown": 3,
  "permissions": [2],
  "credits": "WaifuCat",
  "extra": {}
};

const list = [
   "xem bố gõ sớ nekkk",
  "tk óc lồn mày ra anh mày chửi mày cho nghe mà học hỏi này con đĩ óc lợn mày trốn đâu rồi con chó mày chốn nổi không mày sợ chạy anh rồi à sợ thì bảo anh một câu chứ sao phải chốn",
"mày xem anh mày chửi mày mà học hỏi này con đĩ ngu đú thì ngu như con chó ý cầm ba cái ngôn xàm đòi đọ à oai với mạng xã hội tưởng mình ngầu à",
"mẹ mày bị tao cưỡng hiếp hôm qua ý mẹ mày còn đưa lồn chó liếm nữa ý con lộ link nữa ý xem không cái lồn mẹ mày thâm xì à ",
"mày óc cái lồn mà đúng không cúi xuống kiếm giày năn nỉ tao đi tao tha kkk anh tha cho mày mày đừng đi sủa bạy nha con ngu ngục óc lồn ",
"mày ẳng gì dị con đĩ sao mày gõ chậm thế nghe nói mày sợ tao nên mày gõ chậm đúng không tao biết mà sợ thì bảo anh anh tha cho ",
"ê mày nghe bảo mày thèm cứt tao hả đúng không thấy cno bảo ",
"Tr ơi mày gõ sớ sao bâyh mày qua mày nhây có dòng z hả anh cấm mày nhây mà mày gõ sớ từ đây đến tối cho anh anh mà thấy mày câm là anh phán tội chết cho cả dòng họ mày",
"thiên thời địa lợi nhân hòa anh đây đứng vinh quang dẫm đạp con đĩ mẹ mày từng ngày",
"Tr ơi anh đạp đổ sự nghiệp mày xuống anh đi lên mà thằng vô danh bần cùng nghèo hèn bẩn bựa chả được cái mẹ gì ngoài cái mõm xạo lồn hả",
"đụ con đĩ mẹ mày nghe trời thiên lệnh đức tao bay xuống đây bóp vô cái lồn mẹ mày nè",
"Mày gõ nhây là cái đỉ mẹ mày bị anh đụ rách màn chinh thay chinh mới liền tin hơn đụ con đĩ mẹ mày sao tao phỉa mạnh mẽ với một đối thủ yếu kém như mày",
"mày run cặc chưa con tk óc chóa mày tin tao cho mày xuống âm phủ gặp hắc bạch vô thường để cầm cái lưỡi hái tử thần xiên con cặc mày ra cho tụi tao nướng vất cho con chó nhà mày nhai khôg vậy :))",
"mày đoán xem thử xem cái tốc độ đó của mày có thể ăn được tao không, chậm vậy sao cứu được con đĩ mẹ mày nhanh lên đi chứ:)))",
"Tr ơi mày gõ như đống tro tàn cốt mã sao có 1 ngôn mà mày lặp lại liên thuyên chả có gái mẹ gì cả để anh sợ ngôn gì ko có đầu có kết gõ xàm gõ điên chả ra cái hệ thống phèn chua của cả gia đình tổ tiên mày bị anh moi ruột quăng xuống sông hoàng hà rửa sạch quân thù dưới đất của quân thù",
"anh đây là bẳng tổ khai thiên một tay nhưng đầu con đĩ mẹ mày xuống sông hoàng hà chứu đĩ mẹ mày lên đây cầm cái ngữ bồng sơn lan xơ gan cổ trướng mà so tài cao thấp với anh",
"gõ chậm như chó ý cx đòi gõ à con mả mẹ mày con óc lồn ngu ngục ăn cứt chết  mẹ mày đi con đĩ gõ nổi vs tụi anh nổi mấy ngày không mà đòi sài con laptop ghẻ mà cũng đòi đú à con oc heo lồn mẹ m bị tao địt cho chết mẹ mày ý con đĩ qua ba mày bị đâm lòi ruột ra ngoài á không bt mày có hấng không con ngu ngục bất hiếu làm đc địt gì đâu mà oai óc cứt giám kèo với tụi anh không mà oai mình tao đủ cân cả nhà mày luôn đó con đĩ  ngu ngục ăn cứt tao đk con ngu heheh yêu em lắm đấy xin hãy gõ nhanh lên tí đi chậm quá rồi đó",
"Mày xảo biện 1 hồi là anh lấy nước anh rửa tội cho cả gia đình mày bằng nước thánh thiên liêng từ đầu nguồn bị anh đái lên não nè",
"con ngu ngục cặc đag màn vs tụi t mà :)) nhma cái đụ mẹ nó sớ nó như con cặc á nó đòi dạy đời ai vậy tk ngu mồ côi à hay sao hả tk ngu ê này có gì khác khôg á tk óc chó kìa :)",
"ngồi nghe nè đụ mẹ mày ngồi cầm giấy bút ký tên bán nước cho vật thủy còn dám lên đây cho tài cao thấp với tao hả",
"Tr ơi thế thái nhân sinh như nữ oa nương nương lấy đá vá trời vá sao vá nhầm dô não gái mẹ mày hả cn ôn thú phèn lồn ơi mình tin anh chặt xác mày quăng xuống sông nin rửa tội ngàn đời ko em hả tr ơi anh cầm khăn quàng sanh thắt cổ mày mà",
"đụ con đĩ mẹ mày nói tao nghe đi coi trình độ con đĩ mje mày cỡ nào mà tao đọc cái ghế vô cái bản mặt chó mày ngồi im",
"thiên thời nó ra lệnh cho anh phải chém đầu con đĩ mẹ mày thì dù có bản tọa hay bàn tổ gì xuống đây thì nó cũng xuống lỗ mà chỗ bông túi nhựa đen choàng nhựa đỏ choàng dây thắt cổ con đĩ mẹ mày thôi",
  "Tr ơi mày ơi thời nào r còn dùng cái ngôn thế thái nhân sinh phèn như cộng dậy đọ độ six gái của mày hả v tr ơi t nói cái thế thái nhân sinh như sợt dây đọ lường cái não của mày v á  ầy ơi",
"thế thái nhân sinh nhân tình bạc bẽo con đĩ mẹ mày cố gắng cỡ nào mà dasm lên dây so tài cao thấp để tao coi ngày nó xuống lỗ có làm cho tao xước được miền thịt nào khôn",
"Tr ơi mày gõ nguyên 1 tràn lan đại hải mà gõ chả ra cái hệ thống phèn lồn gì ht mà mày cũng gõ gõ như đường ray hay cái mê cung của nhà mày hay như bộ não ngắn của mày nó lắc léo mà mày lên đáp từng ngôn từng chữ của anh mà mày cũng chậm như rùa bò hả cn thú anh treo thủ cấp gái mẹ mày lên làm não gác bếp anh cho phò đi thay nhau húp rột rột mà mày lên đây mày xảo biện hả cn ôn thú gõ như đống tàn phế của gia đình nó từ thời nhà tống tời h là đủ đầy để anh đổ xuống sông nin anh rửa tội cho cả gia đình mày mà",
"rồi mày nhanh hộ tao đê tk óc cặc bú con cặc tao kìa :)) tk bà già mày làm osin cho nhà tao hay gì vậy mang cứt về cho mày ăn hả -))",
"Tr ơi anh gõ là mày ko thấy trời thấy mây mà mày bị anh rủa cho đầu bù tóc rối gõ xàm gõ điên chả ra hệ thống phèn lồn gì cả mà mày cũng lên đây đáp ngôn hả cn phèn ơi tr ơi anh gõ cho ba mẹ mày deo nhận ra mày là cn ông bả mà sao mày lên đáp lễ xàm lồn gì v hả anh gõ cho mày thấy tam tai trc mắt mà ko bt né mà",
"thế thái nhân sinh nhân tình bạc bẽo con đĩ mẹ mày cố gắng cỡ nào mà dám lên đây so tài cao thấp để tao coi ngày đó xuống lỗ có làm cho tao được xước miếng da miếng thịt nào không",
"mày nhanh con đĩ mẹ mày đi rồi chưa cái máu lồn bà dà mày ngồi thủ dâm hay jz hả tk cặc ngu lồn hả tk lồn mày t cho âm phủ dọn cứt mà -)",
"Tr ơi anh vung tay 1 cái là trời chu đất diệt m gõ chậm như gái mẹ mày bị vong linh nhập thể cầm dao cầm rựa dí mày khắp trời đất v hả cn tgus mày sợ hãi quá qua nhanh anh kêu anh hóa thân thành thầy pháp gõ cho gái mẹ mày bt trời chu đất diệt mà cn ôn thú phèn lồn",
"đụ con đĩ mẹ mày nhắm tao làm chi thì mày về mày hỏi con gái mẹ mày đó đụ má cái cỡ như nó ôm giấc mộng đánh bại được tao  nên sai mày lên đây để cho mày chửi rủa tao mà mày cũng khôn làm được",
"bố mày cũng khép cái đít lạy tk cha mày dưới âm phủ mà tk lồn ê mày biết nhây diss kh á tk cặc sao mà mày ngu lồn vậy hả tk buồi đú 2023 à -))",
"Mày lên đây múa máy mấy cái ngôn xạo lồn từ phương cực lạc từ thiên gia lạc tổ gái mẹ mày bận đi cop ngôn xảo biện vs cha mày hả cn ôn thú bà đặt gõ xàm gõ điên chả ra cái hệ thống cống rãnh gõ như đống tro tàn cốt mã gái mẹ mày chôn từ ngàn đời trc mày lên đâu anh dạy mày 1 khóa làm ng chứ mày làm thú mà mày đòi đứng ngang hàng vs anh hả phương cầy mày gõ như đống tro tàn của gia phả tổ tiên gái mẹ mày để lại cho vạn kiếp sau 1 đời bất hạnh hả",
"Nào mày bằng anh v em hả anh win mày về phần gõ nhanh có ngôn có ngữ mày đáp từng câu từng chữ cho anh xem nè tr ơi anh gõ trùng phương cứu chữa anh gõ ko cho mày đầu thai ngũ tổ phanh thây mà😛",
"cái đĩ mẹ nó rồi nó gõ nhanh chưa vậy hay chậm như cái dái bò thâm hả tk trần thái phương nào mày mạnh bằng anh vậy hả tk lồn xưng bá với ai vậy mày tao sút 10 tk còn dc mà :))",
"Gõ xạo lồn mày tủi cặc gõ vs anh hả mày ôm cái pc ghẻ của mày lên đây đú sớ nào lại anh hả tr ơi anh vung tay 1 cái là trời chu đất diệt anh lên ngôn vua anh chém rớt thủ cấp của gia tộc mày cho mày chu di tam tộc ngũ mã phanh thây đầu thai kiếp mới mày ăn năn xám hối dưới âm ti địa phủ anh hóa thân thành thiên thần lên diệt trùng mấy cn thiên thần xa ngã bị đày đọa xuống âm ti địa phủ mà mày đòi lên mặt vs anh hả cn thiên thần xa ngã mày cỡ mà anh hóa thân thành như lai phật tổ anh chưởng cho mày hồn thoát xác xác phanh thây kh còn nguyên vẹn hả e",
"mày nghĩ mày có thể ăn được tôi hả ông ơi bật giờ ông nhắc thêm con bồ bà già hay dòng họ tổ tiên ông ra đây cùng một lúc chứ đĩ mẹ ông ngồi ôm ba cái ngữ mà tôi tưởng đâu bà đuối tới nơi rồi bây giờ cũng muốn nương tay với ông lắm mà ông hăng quá trời rồi nên tôi phải gõ cho ông tế xuống sông luôn nè",
"thấy nó gõ chậm như cái đĩ mẹ nó treo cổ tự tử xuống diêm vương tìm hộ tk cha nó thất lạc ở dưới hay gì vậy tk chó kia bố mẹ nó mồ côi xuống diêm vương vớt tk con mất dạy nó lên kìa -))",
"Tr ơi mày gõ nào = anh dạ cn ôn thú ngôn anh rồng bay phượng múa ngôn mày có lặp từ lặp ngôn mà mày đòi lên đây bày vẽ mấy cái ngôn như cái mê cung gái mẹ mày chết để lại cho mày đi tìm kho báu về để có tiền cúng gà khoải thân cho gái mẹ mày die rớt tại chỗ hả anh gõ cho con gái mẹ mày chết lâm sàng đột tử tại chỗ mà con phèn ơi anh là diêm la anh phán tội chết cho đỉ mẹ mày mà",
"tất nhiên là tao phải nhanh rồi gõ ba cái mạnh mẽ từ cái thời ông cố nội mày một cánh phi thiên tao đây cũng nhay tay lẹ chân mà gõ theo nó đĩ mẹ nó cho nó bật hồn điên đảo chứ đĩ mẹ mày ngồi ôm giữa 3 giờ sáng ngồi phẩy quạt mo mà cho mày ngủ",
"sủa điên đi mà sủa hăng lên mới vui à thì ra mày là con quái vật bú cu của tao xong bắt con đĩ mẹ mày sục con cặc cho tao hả tk lồn cặc mày súc sinh kìa -))",
"mày mà ngưng một giây là con đĩ mẹ mày bả tắt đường thở á mày gõ chậm mày lên đây để múa mõm vs cha mày hả cn ôn thú mặt xạo lồn vs cha là cha giết gái mẹ mày die tại chỗ nè cn ôn thú anh hảo thiêu xác gái mẹ mày chặt thủ cấp gái mẹ mày rớt xuống dưới âm ti địa phủ nè ",
"bị tao chọc cay hơn con chó luôn xin lỗi mày chứ tao là con quái vật này mà con phế vật con thể hành hạ cho cái da ca nhà mày tan nất rồi cho mày ba bốn chén cơm mà ngồi ôm cái lý tưởng tróc hàn của mày ",
"lag r hả thg óc dái anh hóa thân thành hắc bạch vô thường anh lên anh bắt vong hồn gái mẹ mày xuống chầu diêm vương nó bắt mẹ mày nhận tội phản nghịch quốc gia bị đày đọa xuống dưới diêm la địa phủ bị anh hóa thân thành đầu trâu mặt ngựa phán tội chặt xác mẹ mày quăng xuống sống hoàng hà để rửa tội mà",
"Mày Sài ngôn tiền sử à đòi xưng bá mxh với ai vậy hả tk óc lồn mồ côi cu thì bé mà đòi cân all mxh với ai hả tk lồn mồ côi ê :)) ",
"M cạn ngôn à cn đĩ ngu ngôn tiền sử cmnr có thể hăng ko á đụ má mày gặp tao tinh thần kiệt quậy rồi đuối sức đuối ngôn rồi cầm cái ngôn đã chữ  mà bố chửi cạn từ đĩ mẹ mày đúng không trạng ngữ bị tao gặp tao như là xác thần tao hủy diệt bà già mày luôn",
"thằng bê đê ảo cặc đòi cân và cái kết:>> mày gõ như đống mã gái mẹ mày từ đời cha ông mày để lại cho mày cũng lên đây múa sớ có lại anh đâu mà mày lên đây múa danh ảo ửa gõ nhảm dăm ba mấy cái ngôn ko ra hệ thống cống rãnh gì ht mà lên đây trình bày cái lồn mẹ mày bị thân như dái bò trâu hả cn đỉ anh hóa thân thành hắc bạc vô thường lên bóp não chết đỉ mẹ mày die tới nè",
"bem với cha phải banh đầu óc chó ra đáp lại nghe chưa🤨 nói ngay ngôn ngữ của anh từ cái thời 3 thân bị thía đĩ mẹ mày còn say trời lập địa anh đây một tay quẩy đũa thần công nhưng mà long ngư đi chăn bò đĩ mẹ mày anh cố gõ hết cho mắc cười một xíu để cười chê cho bản mặt chó mày chứ tao nhìn bản mặt mày tao thấy khóc than cho cái thân vô danh quá",
"sao ức chế hả mày gõ như đống tro tàn cốt mã gái mẹ mày được anh đào từ dưới hầm mã chôn dưới 1 lớp đất nguyên 1 cái quàn tài 3 dài 2 ngắn lên đây anh hỏa thiêu sát gái mẹ mày nè cn gà ảo ửa đú sớ mà gõ ko ra hệ thống gì ht v cn gà bại anh rõ mà đú xạo lồn gì mấy sớ ghẻ v hả con gà ",
"con não cún bị chửi kìa nói thiệt chứ một mình anh dưới làn đình thi du tiên múa cột anh giỏi cho con đĩ mẹ mày tan nát xương sườn một thời anh quẩy nát cái cõi càn khôn mà sinh ra cái loại vô danh như mày 🤣🤣🐶",
"mày thấy sớ anh cha tung hoành ngang xương gió hòa mình vào nhiên lên đây gõ cho ba má mày lên đây tụng kinh ăn năn xám hối gõ như đống tro tàn cốt mã gái mẹ mày bị anh treo thủ cấp gái mẹ mày lên trên tường nhà thắp 3 cây hương cúng bái cho gái mẹ mày siêu nhiên hồn siêu phách tán anh quan sát thi thể bà già mày xuất hồn mà",
"thằng bê đê bất lực vì mẹ nó bị đụ tung cái lồn anh nói thiệt chứ con chó cong lồn về ôm con đĩ mẹ mày mà lên đây bố một bể mả cho con đĩ mẹ mày đi tao đây cho một cây gõ mồm con đĩ mẹ mày trên thời địa lợi anh đứng trên đỉnh vinh quang nhìn bà già mày cố gắng gõ ba bốn sáu ngôn từng ngày từng tháng anh gõ cho bà già mày không kịp hóa hồn hóa kiếp",
"con đĩ mẹ mày bất lực vì bị tao chửi mà chỉ biết câm lặng làm màu mà bị tao chửi rung cái con cặc mẹ mày bị tao đụ lòi hột le Không được cay cha nha cha m nói thế thôi chứ lỡ khi m cay cha thật thì phải làm sao hả đú🤣🤣 ",
"Sao m yếu đuối thể hả hăng hái lên đê ai cho m đuối v con chó ngu  cha chx cho m yếu mà thằng cu li ê ái địt con mẹ mày thg ngu ơi m sủa t xem di nào , con thú ăn cứt mxh:)) ",
"thg ngu bị cha chửi đéo ngấc đầu lên nổi ngấc lên cha dập nằm xuống lại t thấy m cay cha lắm rồi thg bất hiếu địt bà nội sư gia nhà m con đĩ mặt lồn đú với anh à nhắm đú nổi với anh không đéo có danh mà đòi đú với anh à",
"Gặp cha sao phải cuống cuồng lên thế🤣",
"Mếu máo rõ mà rồi sao nữa ht ngôn à Yếu kém v thú đú nhảm lồn đú ửa kiểu Hay bị hành quá nên núp Sao v mặt căng v cay cha rồi hả 🤨🌶?",
"Cay cha rõ mà sao xạo lồn hảNhìn mày gõ như đống tro tàn cốt mã nhà mày để lại cho mày vậy á Không được cay anh quá mà làm liều nghe chưa!",
"Đừng bị anh chửi nhiều quá mà tự ái nhảy lầu tự tử nhé anh mà thấy mày lên mạng xã hội tạo nét là anh hành mày mếu máo đó khi nào có trình r đọ với anh chứ trình không có mà sủa hăng ghê ta ",
"Con điếm phò mã bị cha mày cầm cái cây chà bồn cầu cha chà nát lồn mày nè con thú ngu dốt bị cha mày hành cho đầu óc quay cuồng r à ao cay hả cay r làm được gì không hay chỉ được ngồi gõ nhảm bển 🌶",
"Đú sao lại được hả cn ngồi ôm phím gõ dăm ba mấy cái ngôn xưa lắc xưa lơ cha mày hóa thân thành hắc bạch vô thường cha mày bắt hồn đĩ mẹ mày xuống chầu diêm vương con chó mày hăng hái lên xem nào hay bị cha mày bón cho 1 kí hành dô mõm nên không dám sủa nữa",
"cái thứ con người mà não còn không có mà đòi đọ với ai nhìn mặt mày như con tinh tinh đầu thai chuyển kiếp thành con người v nnhìn mặt mày là thấy 2 chữ phèn ngu😗",
"Đã nghèo đã phèn đã ngu đã dốt mà đòi hơn ai ản thân mình không làm được cho mình thì làm được cho ai",
"Sống như 1 con chó ngu dốt như lũ phèn ói chợ búa cầm dao múa kiếm sủa hăng hái lên chứ yếu kém quá cha mày hăng không nổi còn chiêu nào không tung ra đi",
"Chứ thấy mấy cái chiêu trò phèn của mày đi trong ruột mày từ 7 kiếp r bị cha mày hành nhiều quá nên sính ra hoa tưởng hả con sống ngu mà con hay tạo nét quá v cn thú ngu êy ccon thú ngu bị cha mày hành nhìu quá nên không dám sủa nữa à",
"Nhìn mày gõ như đống tro tàn cốt mã nhà mày để lại cho mày vậy á không được cay anh quá mà làm liều nghe chưa đừng bị anh chửi nhiều quá mà tự ái nhảy lầu tự tử nhé",

];

let index = 0;
let isStopped = false;

export function Running({ message }) {
  const args = message.body.split(" ").slice(1); 
  if (args[0] === "stop") {
    isStopped = true; 
    message.send("");
    return;
  }
  
  if (isStopped) {
    isStopped = false;
  }
  
  const sendText = () => {
    message.send(list[index]);
    index = (index + 1) % list.length;
    if (!isStopped) {
      setTimeout(sendText, 7000); 
    }
  };
  sendText();
}

export default {
  config,
  Running
};