Just put your .gif files here, it will randomly send one of them!
