﻿import chalk from 'chalk';

const logger = {
  info: (message) => {
    console.log(chalk.bold.hex('#1d542f').bold('[thông tin]» ')+message);
  },
  warn: (message) => {
    console.log(chalk.bold.hex('#945f2b').bold('[thông báo]» ')+message);
  },
  error: (message) => {
    console.log(chalk.bold.hex('#942b2b').bold('[lỗi]» ')+message);
  },
  system: (message) => {
    console.log(chalk.bold.hex('#f59e42').bold('[hệ thống]» ')+message);
  },
  custom: (message,type,color = "\x1b[36m") => {
    console.log(`${color}[${type}]\x1b[0m ${message}`);
  }
}
export default logger;