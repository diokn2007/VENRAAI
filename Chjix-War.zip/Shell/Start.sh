#! /bin/bash
clear

node nhatcoder