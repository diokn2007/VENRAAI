#!bin/bash
clear
node Active